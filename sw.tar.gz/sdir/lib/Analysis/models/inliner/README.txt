Reference model for inliner -Oz decision policy.
Note that, currently, this model is also referenced by test/Transforms/Inline/ML
tests - if replacing it, check those tests, too.
